const CACHE_NAME = "unik-rastreia-v1";
const ASSETS = [
  "./",
  "./index.html",
  "./home.html",
  "./mapa.html",
  "./perfil.html",
  "./clube.html",
  "./faturas.html",
  "./js/config.js",
  "./manifest.json"
];

// Instalação do Service Worker
self.addEventListener("install", (e) => {
  e.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS);
    })
  );
});

// Ativação e limpeza de caches antigos
self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keyList) => {
      return Promise.all(
        keyList.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    })
  );
});

// Intercepta requisições (Offline first)
self.addEventListener("fetch", (e) => {
  e.respondWith(
    caches.match(e.request).then((response) => {
      return response || fetch(e.request);
    })
  );
});